var _0x9952 = ["chalk", "moment", "discord.js", "../RoomID.json", "prefix", "exports", "\x5B\x43\x6F\x64\x65\x20\x42\x79\x20\x56\x6F\x20\x4C\x65\x20\x4D\x69\x6E\x68\x5D\x20\x42\x4F\x54\x3A\x20\u0110\x61\x6E\x67\x20\x68\x6F\u1EA1\x74\x20\u0111\u1ED9\x6E\x67\x2C\x20\x63\xE1\x63\x20\x6C\u1EC7\x6E\x68\x20\u0111\xE3\x20\u0111\u01B0\u1EE3\x63\x20\x74\u1EA3\x69\x21", "log", "[Code By Vo Le Minh] BOT: ", "username", "user", "\x20\u0110\u0103\x6E\x67\x20\x6E\x68\u1EAD\x70\x20\x62\u1EB1\x6E\x67\x20\x74\xEA\x6E\x21", "online", "setStatus"];
const chalk = require(_0x9952[0]);
const moment = require(_0x9952[1]);
const Discord = require(_0x9952[2]);
const ayarlar = require(_0x9952[3]);
var prefix = ayarlar[_0x9952[4]];
module[_0x9952[5]] = (_0xd5e1x6) => {
    console[_0x9952[7]](`${_0x9952[6]}`);
    console[_0x9952[7]](`${_0x9952[8]}${_0xd5e1x6[_0x9952[10]][_0x9952[9]]}${_0x9952[11]}`);
    _0xd5e1x6[_0x9952[10]][_0x9952[13]](_0x9952[12])
}