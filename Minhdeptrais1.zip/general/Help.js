const Discord = require("discord.js");

exports.run = async (client, message, args) => {

const host = message.content.split (" ")[1]
const port = message.content.split (" ")[2]
const duration = message.content.split (" ")[3]
const ayarlar = require('../RoomID.json');
var room = ayarlar.commandroom;

if (message.channel.id != room) {
	return;
  }

// Example command
if(!args[0]) {
	const embed1 = new Discord.MessageEmbed()
	.setColor('RANDOM')
	.setTitle('HELP ATTACK !')
	.setDescription("```.Help : Check Command !``` \n ```.Methods : View Command Attack !``` \n ```.Geoip : Check Ip WebSite !```")
	.setFooter("Developer By : Vo Le Minh")
	.setTimestamp()
	message.channel.send(embed1);
	return;
	}
  }


exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ['Help'],
  permLevel: 0
}

exports.help = {
  name: 'Help',
  description: 'Minh',
  usage: 'Help'
}
